package model;

public enum TipoObra {
    LIVRO,
    TRABALHO_ACADEMICO,
    REVISTA
}
