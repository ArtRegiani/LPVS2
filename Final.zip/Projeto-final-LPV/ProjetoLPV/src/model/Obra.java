package model;

import java.util.List;

public class Obra {
    private String titulo;
    private List<String> autores;
    private int anoPublicacao;
    private TipoObra tipoObra; 
    private int quantidadeDisponivel;
    private int diasDevolucao;

    public Obra(String titulo, List<String> autores, int anoPublicacao, TipoObra tipoObra, int quantidadeDisponivel, int diasDevolucao) {
        this.titulo = titulo;
        this.autores = autores;
        this.anoPublicacao = anoPublicacao;
        this.tipoObra = tipoObra;
        this.quantidadeDisponivel = quantidadeDisponivel;
        this.diasDevolucao = diasDevolucao;
    }

    // Getters e Setters

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public List<String> getAutores() {
        return autores;
    }

    public void setAutores(List<String> autores) {
        this.autores = autores;
    }

    public int getAnoPublicacao() {
        return anoPublicacao;
    }

    public void setAnoPublicacao(int anoPublicacao) {
        this.anoPublicacao = anoPublicacao;
    }

    public TipoObra getTipoObra() {
        return tipoObra;
    }

    public void setTipoObra(TipoObra tipoObra) {
        this.tipoObra = tipoObra;
    }

    public int getQuantidadeDisponivel() {
        return quantidadeDisponivel;
    }

    public void setQuantidadeDisponivel(int quantidadeDisponivel) {
        this.quantidadeDisponivel = quantidadeDisponivel;
    }

	public int getDiasDevolucao() {
		return diasDevolucao;
	}

	public void setDiasDevolucao(int diasDevolucao) {
		this.diasDevolucao = diasDevolucao;
	}
    
    

}
