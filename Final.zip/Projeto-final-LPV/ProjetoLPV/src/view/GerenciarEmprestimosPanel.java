package view;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import controller.ControleEmprestimo;
import model.Emprestimo;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.util.List;

public class GerenciarEmprestimosPanel extends JPanel {
	private JTextField campoPesquisarNome;
	private JButton botaoPesquisar;
	private JTable tabelaEmprestimos;
	private DefaultTableModel tabelaModeloEmprestimos;
	private JButton botaoRealizarDevolucao;

	ControleEmprestimo controleEmprestimo = ControleEmprestimo.getInstancia();

	public GerenciarEmprestimosPanel() {
		setLayout(new BorderLayout());

		// Painel para pesquisa de empréstimos
		JPanel painelPesquisa = new JPanel(new BorderLayout());
		campoPesquisarNome = new JTextField();
		botaoPesquisar = new JButton("Pesquisar Empréstimos");
		painelPesquisa.add(campoPesquisarNome, BorderLayout.CENTER);
		painelPesquisa.add(botaoPesquisar, BorderLayout.EAST);

		botaoPesquisar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				atualizarTabela();
			}
		});

		// Tabela para exibir os empréstimos
		tabelaModeloEmprestimos = new DefaultTableModel();
		tabelaModeloEmprestimos.addColumn("Nome do Responsável");
		tabelaModeloEmprestimos.addColumn("Data do Empréstimo");
		tabelaModeloEmprestimos.addColumn("Data de Devolução");

		tabelaEmprestimos = new JTable(tabelaModeloEmprestimos);

		// Adiciona um listener para detectar a seleção na tabela
		tabelaEmprestimos.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
			@Override
			public void valueChanged(ListSelectionEvent e) {
				habilitarBotaoDevolucao();
			}
		});

		// Botão para realizar devolução
		botaoRealizarDevolucao = new JButton("Realizar Devolução");
		botaoRealizarDevolucao.setEnabled(false);

		// Adiciona um listener para o botão de realizar devolução
		botaoRealizarDevolucao.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent e) {
		        Emprestimo emprestimoSelecionado = obterEmprestimoSelecionado();
		        realizarDevolucao(emprestimoSelecionado);
		    }
		});

		// Painel principal
		JPanel painelPrincipal = new JPanel(new BorderLayout());
		painelPrincipal.add(painelPesquisa, BorderLayout.NORTH);
		painelPrincipal.add(new JScrollPane(tabelaEmprestimos), BorderLayout.CENTER);
		painelPrincipal.add(botaoRealizarDevolucao, BorderLayout.SOUTH);

		// Adiciona o painel principal ao painel geral
		add(painelPrincipal, BorderLayout.CENTER);

	}

	private List<Emprestimo> atualizarTabela() {
		// Limpar a tabela
		tabelaModeloEmprestimos.setRowCount(0);

		// Obter os empréstimos com base no nome do responsável
		String nomeResponsavel = campoPesquisarNome.getText().trim();
		List<Emprestimo> emprestimos = controleEmprestimo.buscarEmprestimosPorResponsavel(nomeResponsavel);

		// Preencher a tabela com os empréstimos encontrados
		for (Emprestimo emprestimo : emprestimos) {
			tabelaModeloEmprestimos.addRow(new Object[] { emprestimo.getResponsavel(), emprestimo.getDataEmprestimo(),
					emprestimo.getDataDevolucaoPrevista(),

			});
		}
		return emprestimos;
	}

	// Método para habilitar/desabilitar o botão de realizar devolução
	private void habilitarBotaoDevolucao() {
		botaoRealizarDevolucao.setEnabled(tabelaEmprestimos.getSelectedRow() != -1);
	}

	// Método para realizar a devolução
	private void realizarDevolucao(Emprestimo emprestimoSelecionado) {
	    if (emprestimoSelecionado != null) {
	        // Verifica se o empréstimo já foi devolvido
	        if (!emprestimoSelecionado.isDevolvido()) {
	            // Realiza a devolução
	            controleEmprestimo.realizarDevolucao(emprestimoSelecionado);
	            
	            // Atualiza a tabela após a devolução
	            atualizarTabela();
	            
	            // Informa ao usuário que a devolução foi realizada
	            JOptionPane.showMessageDialog(this, "Devolução realizada com sucesso.");
	        } else {
	            // Informa ao usuário que o empréstimo já foi devolvido
	            JOptionPane.showMessageDialog(this, "Este empréstimo já foi devolvido anteriormente.");
	        }
	    } else {
	        JOptionPane.showMessageDialog(this, "Selecione um empréstimo para realizar a devolução.");
	    }
	}
	
	private Emprestimo obterEmprestimoSelecionado() {
	    int linhaSelecionada = tabelaEmprestimos.getSelectedRow();
	    if (linhaSelecionada != -1) {
	        // Obtém a linha selecionada e retorna o empréstimo correspondente
	        String nomeResponsavel = (String) tabelaModeloEmprestimos.getValueAt(linhaSelecionada, 0);
	        LocalDate dataEmprestimo = (LocalDate) tabelaModeloEmprestimos.getValueAt(linhaSelecionada, 1);

	        // Agora, você pode utilizar esses valores para buscar o empréstimo no controle
	        return controleEmprestimo.buscarEmprestimoPorResponsavelEData(nomeResponsavel, dataEmprestimo);
	    }
	    return null;
	}


}
