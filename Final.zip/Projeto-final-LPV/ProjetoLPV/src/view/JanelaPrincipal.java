package view;
import java.util.List;

import javax.swing.*;

import controller.ControleEmprestimo;
import controller.ControleObras;
import model.Emprestimo;


public class JanelaPrincipal extends JFrame {
    public JanelaPrincipal() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 500);

        JTabbedPane abas = new JTabbedPane();
        
        abas.addTab("Gerenciar Obras", new GerenciamentoObrasPanel());
        
        abas.addTab("Realizar Empréstimos", new RealizarEmprestimosPanel());
       
        abas.addTab("Gerenciar Empréstimos", new GerenciarEmprestimosPanel());
        

        getContentPane().add(abas);

        setLocationRelativeTo(null);
        setVisible(true);
    }

}
