package view;

import model.Livro;
import model.Obra;
import model.Revista;
import model.TipoObra;
import model.TrabalhoAcademico;
import controller.ControleObras;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

public class GerenciamentoObrasPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTextField campoTitulo;
	private JTextField campoAnoPublicacao;
	private JTextField campoNumExemplares;
	private JComboBox<TipoObra> comboBoxTipoObra;
	private JTextField campoAutor;
	private JTextField campoVariavel;

	private JPanel painelAutores;
	private DefaultTableModel tabelaModelo;
	private JTable tabelaObras;
	private JLabel lblVariavel = new JLabel("Editora:");

	private List<String> autores;

	ControleObras controleObras = ControleObras.getInstancia();
	List<Obra> listObras = controleObras.listarObras();

	public GerenciamentoObrasPanel() {
		autores = new ArrayList<>();

		setLayout(new BorderLayout());

		// Painel para os campos de entrada
		JPanel painelEntrada = new JPanel(new GridLayout(7, 2));

		// Campos de entrada
		campoTitulo = new JTextField();
		campoAnoPublicacao = new JTextField();
		campoNumExemplares = new JTextField();
		comboBoxTipoObra = new JComboBox<>(TipoObra.values());
		campoAutor = new JTextField();
		campoVariavel = new JTextField();

		// Botão para adicionar autor
		JButton botaoAdicionarAutor = new JButton("Adicionar");
		botaoAdicionarAutor.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				adicionarAutor();
			}
		});

		comboBoxTipoObra.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				atualizarTextoLabel();
			}

		});

		// Adiciona os componentes ao painel de entrada
		painelEntrada.add(new JLabel("Título:"));
		painelEntrada.add(campoTitulo);
		painelEntrada.add(new JLabel("Ano de publicação:"));
		painelEntrada.add(campoAnoPublicacao);
		painelEntrada.add(new JLabel("Número de exemplares:"));
		painelEntrada.add(campoNumExemplares);
		painelEntrada.add(new JLabel("Tipo de obra:"));
		painelEntrada.add(comboBoxTipoObra);
		painelEntrada.add(new JLabel("Nome do autor:"));
		painelEntrada.add(campoAutor);
		painelEntrada.add(new JLabel("Clique no botão para adicionar o(s) autor(es)"));
		painelEntrada.add(botaoAdicionarAutor);
		painelEntrada.add(lblVariavel);
		painelEntrada.add(campoVariavel);

		// Painel para exibir os autores em formato de text-tag
		painelAutores = new JPanel(new FlowLayout(FlowLayout.LEFT));

		// Tabela para exibir as obras cadastradas
		tabelaModelo = new DefaultTableModel();
		tabelaModelo.addColumn("Título");
		tabelaModelo.addColumn("Ano de Publicação");
		tabelaModelo.addColumn("Tipo");
		tabelaModelo.addColumn("Número de Exemplares");
		tabelaModelo.addColumn("Autores");

		tabelaObras = new JTable(tabelaModelo);

		// Painel para a tabela
		JPanel painelTabela = new JPanel(new BorderLayout());
		painelTabela.add(new JScrollPane(tabelaObras), BorderLayout.CENTER);

		// Painel principal organizado verticalmente
		JPanel painelPrincipal = new JPanel(new GridLayout(3, 1));
		painelPrincipal.add(painelEntrada);
		painelPrincipal.add(new JScrollPane(painelAutores));
		painelPrincipal.add(painelTabela);

		// Botões para cadastrar e remover obra
		JButton botaoCadastrarObra = new JButton("Cadastrar Obra");
		botaoCadastrarObra.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				cadastrarObra();
			}
		});

		JButton botaoRemoverObra = new JButton("Remover Obra Selecionada");
		botaoRemoverObra.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int linhaSelecionada = tabelaObras.getSelectedRow();
				if (linhaSelecionada != -1) {
					removerObra(linhaSelecionada);
				} else {
					JOptionPane.showMessageDialog(GerenciamentoObrasPanel.this, "Selecione uma obra para remover.");
				}
			}
		});

		// Painel para os botões
		JPanel painelBotoes = new JPanel();
		painelBotoes.add(botaoCadastrarObra);
		painelBotoes.add(botaoRemoverObra);

		// Adiciona os componentes ao painel principal
		add(painelPrincipal, BorderLayout.CENTER);
		add(painelBotoes, BorderLayout.SOUTH);

		// adiciona obras temporárias e atualiza tabela
		controleObras.adicionarObrasTemporarias();
		atualizaTabela();
	}

	private void adicionarAutor() {
		String autor = campoAutor.getText().trim();
		if (!autor.isEmpty() && !autores.contains(autor)) {
			autores.add(autor);
			atualizarPainelAutores();
			campoAutor.setText(""); // Limpa o campo após adicionar
		}
	}

	private void atualizarPainelAutores() {
		// Limpa o painel antes de adicionar os autores novamente
		painelAutores.removeAll();

		// Adiciona os autores em formato de text-tag com botão de remoção
		for (String autor : autores) {
			JButton botaoRemoverAutor = new JButton("X");
			botaoRemoverAutor.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					removerAutor(autor);
				}
			});
			JLabel labelAutor = new JLabel(autor);
			labelAutor.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(Color.BLACK),
					BorderFactory.createEmptyBorder(2, 2, 2, 2)));
			JPanel painelAutor = new JPanel(new FlowLayout(FlowLayout.LEFT));
			painelAutor.add(labelAutor);
			painelAutor.add(botaoRemoverAutor);
			painelAutores.add(painelAutor);
		}

		// Atualiza a interface
		painelAutores.revalidate();
		painelAutores.repaint();
	}

	private void atualizaTabela() {
		// atualiza lista de obras
		List<Obra> listObras = controleObras.listarObras();
		// limpa tabela antes de atualizar
		tabelaModelo.setRowCount(0);
		for (Obra obra : listObras) {
			tabelaModelo.addRow(new Object[] { obra.getTitulo(), obra.getAnoPublicacao(), obra.getTipoObra(),
					obra.getQuantidadeDisponivel(), String.join(", ", obra.getAutores()) });
		}
	}

	private void removerAutor(String autor) {
		autores.remove(autor);
		atualizarPainelAutores();
	}

	private void cadastrarObra() {
		// Obter a obra a partir dos campos de entrada
		Obra novaObra = criarObra();

		// Adicionar a obra à tabela
		adicionarObraTabela(novaObra);

		// Limpar os campos de entrada
		campoTitulo.setText("");
		campoAnoPublicacao.setText("");
		campoNumExemplares.setText("");
		comboBoxTipoObra.setSelectedIndex(0);
		campoAutor.setText("");
		autores.clear();
		atualizarPainelAutores();
	}

	private void removerObra(int linha) {
		// Obtém o título da obra na linha selecionada
		String tituloObra = (String) tabelaModelo.getValueAt(linha, 0);

		// Procura a obra na lista de controle de obras
		Obra obraParaRemover = null;
		for (Obra obra : listObras) {
			if (obra.getTitulo().equals(tituloObra)) {
				obraParaRemover = obra;
				break;
			}
		}

		// Remove a obra da lista de controle de obras
		if (obraParaRemover != null) {
			controleObras.removerObra(obraParaRemover);
			// Atualiza a tabela após remover a obra
			atualizaTabela();
		} else {
			JOptionPane.showMessageDialog(GerenciamentoObrasPanel.this,
					"Não foi possível encontrar a obra para remover.");
		}
	}

	// Método para adicionar uma obra à tabela
	private void adicionarObraTabela(Obra obra) {
		listObras.add(obra);
		atualizaTabela();
	}

	// Método para obter os dados da obra a partir dos campos de entrada
	private Obra criarObra() {
		String titulo = campoTitulo.getText();
		int anoPublicacao = Integer.parseInt(campoAnoPublicacao.getText());
		int numExemplares = Integer.parseInt(campoNumExemplares.getText());
		TipoObra tipoObra = (TipoObra) comboBoxTipoObra.getSelectedItem();
		List<String> autores = getAutores();

		switch (tipoObra) {
		case LIVRO: {

			return new Livro(titulo, autores, anoPublicacao, numExemplares, campoVariavel.getText());
		}
		case REVISTA: {
			return new Revista(titulo, autores, anoPublicacao, numExemplares, 2);
		}
		case TRABALHO_ACADEMICO: {
			return new TrabalhoAcademico(titulo, autores, anoPublicacao, numExemplares, campoVariavel.getText());
		}
		default:
			JOptionPane.showMessageDialog(null, "Erro na criação do objeto", "Erro", JOptionPane.INFORMATION_MESSAGE);

		}
		return null;

	}

	private void atualizarTextoLabel() {
		TipoObra opcaoSelecionada = (TipoObra) comboBoxTipoObra.getSelectedItem();
		switch (opcaoSelecionada) {
		case LIVRO:
			lblVariavel.setText("Editora:");
			break;
		case REVISTA:
			lblVariavel.setText("Edição:");
			break;
		case TRABALHO_ACADEMICO:
			lblVariavel.setText("Instituição:");
			break;
		}

	}

	public List<String> getAutores() {
		return new ArrayList<>(autores);
	}
}
