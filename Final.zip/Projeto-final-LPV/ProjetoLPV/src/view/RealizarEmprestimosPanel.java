package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.MaskFormatter;

import controller.ControleEmprestimo;
import controller.ControleObras;
import model.Obra;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class RealizarEmprestimosPanel extends JPanel {
	private JTextField campoPesquisa;
	private JButton botaoPesquisar;
	private JTable tabelaResultados;
	private DefaultTableModel tabelaModeloResultados;
	private JTable tabelaObrasSelecionadas;
	private DefaultTableModel tabelaModeloSelecionadas;
	private JTextField campoNomeUsuario;
	private JFormattedTextField campoDataEmprestimo ;
	private JButton botaoRemoverObra;

	ControleEmprestimo controleEmprestimo = ControleEmprestimo.getInstancia();

	ControleObras controleObras = ControleObras.getInstancia();
	private List<Obra> listSelecionadas = new ArrayList<>();
	private List<Obra> listPesquisa = new ArrayList<>();

	public RealizarEmprestimosPanel() {

		setLayout(new BorderLayout());

		// Painel para pesquisa

		JPanel painelPesquisa = new JPanel();
		campoPesquisa = new JTextField(20);
		botaoPesquisar = new JButton("Pesquisar");

		botaoPesquisar.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				pesquisarObras();
			}
		});

		painelPesquisa.add(new JLabel("Pesquisar: "));
		painelPesquisa.add(campoPesquisa);
		painelPesquisa.add(botaoPesquisar);

		// Tabela para resultados da pesquisa
		tabelaModeloResultados = new DefaultTableModel();
		tabelaModeloResultados.addColumn("Título");
		tabelaModeloResultados.addColumn("Ano de Publicação");
		tabelaModeloResultados.addColumn("Tipo de Obra");
		tabelaModeloResultados.addColumn("Número de Exemplares");
		tabelaModeloResultados.addColumn("Autores");

		tabelaResultados = new JTable(tabelaModeloResultados);

		// Adiciona um listener de clique para a tabela de resultados
		tabelaResultados.addMouseListener(new java.awt.event.MouseAdapter() {
			public void mouseClicked(java.awt.event.MouseEvent evt) {
				int linha = tabelaResultados.rowAtPoint(evt.getPoint());
				if (linha >= 0) {

					selecionarObra(linha);
				}
			}
		});

		// Painel para tabela de resultados
		JPanel painelResultados = new JPanel(new BorderLayout());
		painelResultados.add(new JScrollPane(tabelaResultados), BorderLayout.CENTER);
		
		
		 MaskFormatter dateFormatter = null;
         try {
             dateFormatter = new MaskFormatter("##-##-####");
             dateFormatter.setPlaceholderCharacter('_'); // Caractere para espaços em branco não preenchidos
         } catch (ParseException e) {
             e.printStackTrace();
         }
         

         
		

		// Painel para informações de empréstimo
		JPanel painelEmprestimo = new JPanel(new GridLayout(3, 2));
		campoNomeUsuario = new JTextField();
		
		campoDataEmprestimo = new JFormattedTextField(dateFormatter);
		campoDataEmprestimo.setColumns(10);
		painelEmprestimo.add(new JLabel("Nome do Usuário:"));
		painelEmprestimo.add(campoNomeUsuario);
		painelEmprestimo.add(new JLabel("Data do Empréstimo:"));
		painelEmprestimo.add(campoDataEmprestimo);

		// Tabela para obras selecionadas para empréstimo
		tabelaModeloSelecionadas = new DefaultTableModel();
		tabelaModeloSelecionadas.addColumn("Título");
		tabelaModeloSelecionadas.addColumn("Ano de Publicação");
		tabelaModeloSelecionadas.addColumn("Tipo de Obra");
		tabelaModeloSelecionadas.addColumn("Número de Exemplares");
		tabelaModeloSelecionadas.addColumn("Autores");

		tabelaObrasSelecionadas = new JTable(tabelaModeloSelecionadas);

		// Painel para tabela de obras selecionadas
		JPanel painelObrasSelecionadas = new JPanel(new BorderLayout());
		painelObrasSelecionadas.add(new JScrollPane(tabelaObrasSelecionadas), BorderLayout.CENTER);

		// Botão para realizar empréstimo
		JButton botaoRealizarEmprestimo = new JButton("Realizar Empréstimo");
		botaoRealizarEmprestimo.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				realizarEmprestimo();
			}
		});

		// Painel para botão de realizar empréstimo
		JPanel painelBotaoEmprestimo = new JPanel();
		painelBotaoEmprestimo.add(botaoRealizarEmprestimo);

		botaoRemoverObra = new JButton("Remover Obra Selecionada");
		botaoRemoverObra.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				removerObraSelecionada();
			}
		});

		// Painel para botão de remover obra
		JPanel painelBotaoRemoverObra = new JPanel();
		painelBotaoRemoverObra.add(botaoRemoverObra);

		// Rótulo para a tabela de resultados
		JLabel rotuloTabelaResultados = new JLabel("Resultados da Pesquisa", SwingConstants.CENTER);
		rotuloTabelaResultados.setFont(new Font("Arial", Font.BOLD, 16));

		// Rótulo para a tabela de obras selecionadas
		JLabel rotuloTabelaSelecionadas = new JLabel("Obras Selecionadas", SwingConstants.CENTER);
		rotuloTabelaSelecionadas.setFont(new Font("Arial", Font.BOLD, 16));

		// Adiciona rótulos e tabelas aos painéis
		JPanel painelRotuloResultados = new JPanel(new BorderLayout());
		painelRotuloResultados.add(rotuloTabelaResultados, BorderLayout.NORTH);
		painelRotuloResultados.add(new JScrollPane(tabelaResultados), BorderLayout.CENTER);
		painelRotuloResultados.setPreferredSize(new Dimension(400, 150)); // Ajuste a altura conforme necessário

		JPanel painelRotuloSelecionadas = new JPanel(new BorderLayout());
		painelRotuloSelecionadas.add(rotuloTabelaSelecionadas, BorderLayout.NORTH);
		painelRotuloSelecionadas.add(new JScrollPane(tabelaObrasSelecionadas), BorderLayout.CENTER);
		painelRotuloSelecionadas.setPreferredSize(new Dimension(400, 150)); // Ajuste a altura conforme necessário

		// Adiciona os painéis com rótulos ao painel principal
		JPanel painelPrincipal = new JPanel(new GridLayout(5, 1));
		painelPrincipal.add(painelPesquisa);
		painelPrincipal.add(painelRotuloResultados);
		painelPrincipal.add(painelEmprestimo);
		painelPrincipal.add(painelRotuloSelecionadas);
		painelPrincipal.add(painelBotaoEmprestimo);
		painelPrincipal.add(painelBotaoRemoverObra);

		add(painelPrincipal, BorderLayout.CENTER);
	}

	private void pesquisarObras() {
		listPesquisa.clear();
		String termoPesquisa = campoPesquisa.getText().trim().toLowerCase();

		tabelaModeloResultados.setRowCount(0); // Limpa a tabela
		for (Obra obra : controleObras.listarObras()) {
			if (obra.getTitulo().toLowerCase().contains(termoPesquisa)
					|| obra.getAutores().toString().toLowerCase().contains(termoPesquisa)
					|| obra.getTipoObra().toString().toLowerCase().contains(termoPesquisa)) {
				listPesquisa.add(obra);
				adicionarObraTabelaResultados(obra);
			}
		}
	}

	private void adicionarObraTabelaResultados(Obra obra) {

		tabelaModeloResultados.addRow(new Object[] { obra.getTitulo(), obra.getAnoPublicacao(), obra.getTipoObra(),
				obra.getQuantidadeDisponivel(), String.join(", ", obra.getAutores()) });
	}

	private void selecionarObra(int linha) {

		Obra obraSelecionada = null;

		obraSelecionada = obterObraDaLinha(linha, listPesquisa);

		if (obraSelecionada != null) {
			listSelecionadas.add(obraSelecionada);
			adicionarObraTabelaSelecionadas(obraSelecionada);
		}
	}

	private void adicionarObraTabelaSelecionadas(Obra obra) {
		tabelaModeloSelecionadas.addRow(new Object[] { obra.getTitulo(), obra.getAnoPublicacao(), obra.getTipoObra(),
				obra.getQuantidadeDisponivel(), String.join(", ", obra.getAutores()) });
	}

	private void realizarEmprestimo() {
		String nomeUsuario = campoNomeUsuario.getText().trim();
		String dataEmprestimo = campoDataEmprestimo.getText().trim();

		if (nomeUsuario.isEmpty() || dataEmprestimo.isEmpty() || listSelecionadas.isEmpty()) {
			JOptionPane.showMessageDialog(this,
					"Preencha todos os campos e selecione pelo menos uma obra para empréstimo.");
		} else {
			
			// Formatador de data
	        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

	        // Converte o texto para LocalDate usando o parse()
	        LocalDate localDate = LocalDate.parse(dataEmprestimo, formatter);
			
			controleEmprestimo.realizarEmprestimo(listPesquisa, localDate, nomeUsuario);

			JOptionPane.showMessageDialog(this, "Empréstimo realizado com sucesso!");
			limparCampos();

		}
	}

	private Obra obterObraDaLinha(int linha, List<Obra> list) {
		if (linha >= 0 && linha < list.size()) {
			return list.get(linha);
		}
		return null;
	}

	private void removerObraSelecionada() {
		int linhaSelecionada = tabelaObrasSelecionadas.getSelectedRow();
		if (linhaSelecionada != -1) {
			Obra obraRemovida = obterObraDaLinha(linhaSelecionada, listSelecionadas);
			if (obraRemovida != null) {
				removerObraTabelaSelecionadas(linhaSelecionada);
				listSelecionadas.remove(obraRemovida);
			}
		} else {
			JOptionPane.showMessageDialog(this, "Selecione uma obra para remover.");
		}
	}

	private void removerObraTabelaSelecionadas(int linha) {
		tabelaModeloSelecionadas.removeRow(linha);
	}

	private void limparCampos() {
		campoPesquisa.setText("");
		campoNomeUsuario.setText("");
		campoDataEmprestimo.setText("");
		tabelaModeloResultados.setRowCount(0);
		tabelaModeloSelecionadas.setRowCount(0);
		listSelecionadas.clear();
	}
}
