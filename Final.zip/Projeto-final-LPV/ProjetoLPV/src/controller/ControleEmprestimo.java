package controller;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import model.Emprestimo;
import model.Obra;

public class ControleEmprestimo {
	private static ControleEmprestimo instancia;
	private List<Emprestimo> emprestimos;

	private ControleEmprestimo() {
		this.emprestimos = new ArrayList<>();
	}

	public static ControleEmprestimo getInstancia() {
		if (instancia == null) {
			instancia = new ControleEmprestimo();
		}
		return instancia;
	}

	public void realizarEmprestimo(List<Obra> obras, LocalDate dataEmprestimo, String responsavel) {

		Emprestimo emprestimo = new Emprestimo(obras, dataEmprestimo, responsavel);

		for (Obra obra : obras) {
			obra.setQuantidadeDisponivel(obra.getQuantidadeDisponivel() - 1);
		}
		emprestimos.add(emprestimo);
	}


	public void realizarDevolucao(Emprestimo emprestimo) {
		for (Obra obra : emprestimo.getObrasEmprestadas()) {
			obra.setQuantidadeDisponivel(obra.getQuantidadeDisponivel() + 1);
		}
		emprestimo.setDevolvido(true);
	}
	
	

	public List<Emprestimo> listarEmprestimos() {
		return emprestimos;
	}

	public List<Emprestimo> listarEmprestimosNaoDevolvidos() {
		List<Emprestimo> naoDevolvidos = new ArrayList<>();
		for (Emprestimo emprestimo : emprestimos) {
			if (!emprestimo.isDevolvido()) {
				naoDevolvidos.add(emprestimo);
			}
		}
		return naoDevolvidos;
	}

	public List<Emprestimo> listarEmprestimosDevolvidos() {
		List<Emprestimo> devolvidos = new ArrayList<>();
		for (Emprestimo emprestimo : emprestimos) {
			if (emprestimo.isDevolvido()) {
				devolvidos.add(emprestimo);
			}
		}
		return devolvidos;
	}

	// lista emprestimos não devolvidos por responsável
	public List<Emprestimo> buscarEmprestimosPorResponsavel(String responsavel) {
		List<Emprestimo> emprestimosEncontrados = new ArrayList<>();
		for (Emprestimo emprestimo : emprestimos) {
			if (emprestimo.getResponsavel().toLowerCase().contains(responsavel)) {
				if (!emprestimo.isDevolvido()) {
					emprestimosEncontrados.add(emprestimo);
				}
			}
		}
		return emprestimosEncontrados;
	}

	public List<Obra> listaObrasEmprestadas(Emprestimo emprestimo) {

		List<Obra> obrasEmprestadas = new ArrayList<>();

		for (Obra obra : emprestimo.getObrasEmprestadas()) {
			obrasEmprestadas.add(obra);
		}
		return obrasEmprestadas;
	}

	public Emprestimo buscarEmprestimoPorResponsavelEData(String responsavel, LocalDate dataEmprestimo) {
	    for (Emprestimo emprestimo : emprestimos) {
	        if (emprestimo.getResponsavel().equalsIgnoreCase(responsavel) &&
	            emprestimo.getDataEmprestimo().equals(dataEmprestimo)) {
	            return emprestimo;
	        }
	    }
	    return null;
	}
}
