package controller;

import java.util.ArrayList;
import java.util.List;

import model.Livro;
import model.Obra;
import model.Revista;
import model.TipoObra;
import model.TrabalhoAcademico;

public class ControleObras {
    private static ControleObras instancia;
    private List<Obra> obras;

    private ControleObras() {
        this.obras = new ArrayList<>();
    }

    public static ControleObras getInstancia() {
        if (instancia == null) {
            instancia = new ControleObras();
        }
        return instancia;
    }

    public void adicionarObra(Obra obra) {
        obras.add(obra);
    }

    public void removerObra(Obra obra) {
        obras.remove(obra);
    }

    public List<Obra> listarObras() {
        return obras;
    }
    
    public List<String> listarNomesObras() {
        List<String> nomesObras = new ArrayList<>();

        for (Obra obra : obras) {
            nomesObras.add(obra.getTitulo());
        }

        return nomesObras;
    }
    
    public List<Obra> pesquisarObrasPorTitulo(String tituloPesquisado) {
    	List<Obra> obrasEncontradas = new ArrayList<>();
    	
    	for (Obra obra : obras) {
    		if (obra.getTitulo().toLowerCase().contains(tituloPesquisado)) {
    			obrasEncontradas.add(obra);
    		}
    	}
    	
    	return obrasEncontradas;
    }
    
    public Obra obterObraPorTitulo(String titulo) {
    	for (Obra obra : obras) {
    		if (obra.getTitulo().equalsIgnoreCase(titulo)) {
    			return obra;
    		}
    	}
    	return null; // Retorna null se a obra não for encontrada
    }
    
    public void adicionarObrasTemporarias() {
        Obra obra1 = new Livro("Livro 1", List.of("Autor1"), 2022, 5, "Brasil");
        Obra obra2 = new Livro("Livro 2", List.of("Autor2"), 2021, 8, "Edit");
        Obra obra3 = new TrabalhoAcademico("Trabalho 1", List.of("Autor3"), 2020, 3, "IFSP");
        Obra obra4 = new Revista("Revista 1", List.of("Autor4"), 2019, 10, 2);
        Obra obra5 = new Livro("Livro 3", List.of("Autor5"), 2023, 7, "Brasil");

        adicionarObra(obra1);
        adicionarObra(obra2);
        adicionarObra(obra3);
        adicionarObra(obra4);
        adicionarObra(obra5);
    }



}
