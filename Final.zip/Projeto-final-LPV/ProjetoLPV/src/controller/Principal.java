package controller;

import javax.swing.SwingUtilities;

import view.JanelaPrincipal;

public class Principal {
	
	public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new JanelaPrincipal());
    }
	

}
